# viperthonix
It will read different datafile and perform basic operation with just one click

## Installation
```pip install viper-thonix```

## Example
from viper-thonix import load
load("D:\data science\ML\ML\class\Admission_Prediction.csv")



## License
© 2021 Swati Pandey

This repository is licensed under the MIT License.
See LICENSE for details.                                                                                                                     